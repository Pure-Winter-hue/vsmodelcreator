package at.vintagestory.modelcreator.enums;

public enum EnumAxis
{
    X,
    Y,
    Z
}