package at.vintagestory.modelcreator.input.command;

public interface ProjectCommand
{
	public void execute();
}
