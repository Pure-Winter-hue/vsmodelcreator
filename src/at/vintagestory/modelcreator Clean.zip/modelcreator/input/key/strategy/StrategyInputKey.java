package at.vintagestory.modelcreator.input.key.strategy;

import at.vintagestory.modelcreator.input.key.InputKeyEvent;

public interface StrategyInputKey
{
	public void execute(InputKeyEvent event);
}
