package at.vintagestory.modelcreator.interfaces;


public interface IDrawable
{
	public void draw(IDrawable selectedElem, boolean drawCallFromStepParent, int animVersion);
}
