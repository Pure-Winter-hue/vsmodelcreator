package at.vintagestory.modelcreator.interfaces;

import javax.swing.JComponent;

public interface IValueUpdater
{
	public void updateValues(JComponent byGuiElem);
}
