package at.vintagestory.modelcreator.model;

public class BooleanParam
{
	public boolean Value;
}
