package at.vintagestory.modelcreator.util;

public enum EnumValueType
{
	Animation,
	Element
}
