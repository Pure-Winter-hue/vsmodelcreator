package at.vintagestory.modelcreator.enums;

public enum EnumNodeType
{
	Cube, Point
}
