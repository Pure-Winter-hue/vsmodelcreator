package at.vintagestory.modelcreator.gui.right.keyframes;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

import at.vintagestory.modelcreator.ModelCreator;
import at.vintagestory.modelcreator.Start;
import at.vintagestory.modelcreator.gui.FrameSelectionDialogDuplicateOnlyThis;
import at.vintagestory.modelcreator.gui.Icons;
import at.vintagestory.modelcreator.interfaces.IValueUpdater;
import at.vintagestory.modelcreator.ik.FloorIkSolver;
import at.vintagestory.modelcreator.model.Element;

public class KeyFrameToolsPanel extends JPanel implements IValueUpdater
{
    private static final long serialVersionUID = 1L;

    private JButton btnDuplicateOnlyThis;
	private JToggleButton btnFloorIk;

    public KeyFrameToolsPanel()
    {
		setLayout(new GridLayout(2, 1, 0, 2));
        setBorder(BorderFactory.createTitledBorder(Start.Border, "<html><b>Tools</b></html>"));
		setMaximumSize(new Dimension(186, 92));

        btnDuplicateOnlyThis = new JButton("Duplicate Only This");
        btnDuplicateOnlyThis.setIcon(Icons.copy);
        btnDuplicateOnlyThis.setToolTipText("<html>Duplicates the current frame to a target frame, but only for the selected element.<br>\nIf a keyframe already exists at the target frame, it will merge/overwrite only that element's keyframe data.</html>");
        btnDuplicateOnlyThis.addActionListener(e -> FrameSelectionDialogDuplicateOnlyThis.show(ModelCreator.Instance));
        add(btnDuplicateOnlyThis);

		btnFloorIk = new JToggleButton("Floor IK");
		btnFloorIk.setToolTipText("<html>Locks the selected element (the foot) against the floor grid (y=0).<br>When the foot would push into the floor, the chain above will rotate to keep contact.</html>");
		btnFloorIk.addActionListener(e -> {
			Element elem = ModelCreator.currentProject == null ? null : ModelCreator.currentProject.SelectedElement;
			boolean on = btnFloorIk.isSelected();
			ModelCreator.floorIkEnabled = on;
			ModelCreator.floorIkFootElement = on ? elem : null;
			FloorIkSolver.resetAnchor();
			ModelCreator.updateValues(btnFloorIk);
		});
		add(btnFloorIk);

        updateValues(null);
    }

    @Override
    public void updateValues(JComponent byGuiElem)
    {
        Element elem = ModelCreator.currentProject == null ? null : ModelCreator.currentProject.SelectedElement;
		boolean enabled = elem != null && ModelCreator.currentProject != null && ModelCreator.currentProject.SelectedAnimation != null && !ModelCreator.AnimationPlaying();
        btnDuplicateOnlyThis.setEnabled(enabled);
		btnFloorIk.setEnabled(enabled);
		btnFloorIk.setSelected(ModelCreator.floorIkEnabled);
		if (ModelCreator.floorIkEnabled && ModelCreator.floorIkFootElement != null) {
			btnFloorIk.setText("Floor IK (" + ModelCreator.floorIkFootElement.getName() + ")");
		} else {
			btnFloorIk.setText("Floor IK");
		}
    }
}
