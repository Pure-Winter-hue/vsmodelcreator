package at.vintagestory.modelcreator.ik;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JComponent;

import org.lwjgl.util.vector.Quaternion;

import at.vintagestory.modelcreator.ModelCreator;
import at.vintagestory.modelcreator.Project;
import at.vintagestory.modelcreator.model.AnimFrameElement;
import at.vintagestory.modelcreator.model.Animation;
import at.vintagestory.modelcreator.model.AnimationFrame;
import at.vintagestory.modelcreator.model.Element;
import at.vintagestory.modelcreator.util.GameMath;
import at.vintagestory.modelcreator.util.Mat4f;
import at.vintagestory.modelcreator.util.QUtil;

/**
 * A lightweight "floor contact" IK helper for keyframe posing.
 *
 * Behavior:
 * - The selected hierarchy element is treated as the foot.
 * - When the foot touches the floor (y=0), the first contacting face/corner becomes the anchor.
 * - If subsequent edits would push the foot below y=0, the chain above is rotated to keep the anchor fixed.
 */
public class FloorIkSolver
{
	private static final float FLOOR_Y = 0f;
	private static final float CONTACT_EPS = 0.0005f;
	private static final float RELEASE_EPS = 0.01f;
	private static final int MAX_ITERS = 12;
	private static final float SOLVE_TOL = 0.001f;

	private static boolean inSolve = false;

	// Anchor state
	private static boolean anchored = false;
	private static String anchoredFootName = null;
	private static float anchorWorldX;
	private static float anchorWorldZ;
	private static float[] anchorLocal = null; // foot-local (x,y,z)

	public static void resetAnchor()
	{
		anchored = false;
		anchoredFootName = null;
		anchorLocal = null;
	}

	public static void applyIfEnabled(JComponent byGuiElem)
	{
		if (inSolve) return;
		if (!ModelCreator.floorIkEnabled) return;
		if (ModelCreator.AnimationPlaying()) return;

			Project project = ModelCreator.CurrentAnimProject();
			if (project == null || project.SelectedAnimation == null) return;

			Element foot = ModelCreator.floorIkFootElement;
			if (foot == null) return;

			// Undo/redo and project reloads swap out the element graph.
			// If we keep an old element reference here, we can accidentally create keyframe
			// elements for a different (detached) graph, corrupting animation state.
			Element rebound = project.findElement(foot.getName());
			if (rebound == null) {
				// Foot no longer exists: disable IK.
				ModelCreator.floorIkEnabled = false;
				ModelCreator.floorIkFootElement = null;
				resetAnchor();
				return;
			}
			if (rebound != foot) {
				ModelCreator.floorIkFootElement = rebound;
				foot = rebound;
				resetAnchor();
			}

		Animation anim = project.SelectedAnimation;
		int frame = anim.currentFrame;

		// Only operate on existing keyframes so we don't create new frames unexpectedly
		AnimationFrame kfFrame = anim.GetKeyFrame(frame);
		if (kfFrame == null) return;

		try {
			inSolve = true;

			// Build chain (foot -> root)
			List<Element> chainFootToRoot = buildChain(foot);
			if (chainFootToRoot.size() < 2) return; // need at least foot + one parent

			// Ensure anchor is based on the current foot
			if (anchored && anchoredFootName != null && !anchoredFootName.equals(foot.getName())) {
				resetAnchor();
			}

			// Compute matrices for current pose (from keyframe data)
			Pose pose = new Pose(chainFootToRoot, anim, kfFrame, frame);
			pose.rebuild();

			ContactInfo contact = computeFootContact(foot, pose.worldByElem.get(foot));
			if (contact == null) {
				resetAnchor();
				return;
			}

			// If foot is above the floor enough, release anchor
			if (contact.minY > FLOOR_Y + RELEASE_EPS) {
				resetAnchor();
				return;
			}

			// Create/refresh anchor when first touching
			if (!anchored || anchorLocal == null) {
				if (contact.minY <= FLOOR_Y + CONTACT_EPS) {
					anchored = true;
					anchoredFootName = foot.getName();
					anchorWorldX = contact.anchorX;
					anchorWorldZ = contact.anchorZ;

					float[] inv = Mat4f.Invert(new float[16], pose.worldByElem.get(foot));
					if (inv != null) {
						float[] local4 = Mat4f.MulWithVec4(inv, new float[] { contact.anchorX, contact.anchorY, contact.anchorZ, 1f });
						anchorLocal = new float[] { local4[0], local4[1], local4[2] };
					} else {
						// fallback: anchor in (approx) foot space
						anchorLocal = new float[] { 0f, 0f, 0f };
					}
				}
			}

			if (!anchored || anchorLocal == null) return;

			float[] target = new float[] { anchorWorldX, FLOOR_Y, anchorWorldZ };

			// Solve only if we're trying to push the foot into the floor (or drifted away)
			float[] current = getAnchorWorld(foot, pose.worldByElem.get(foot));
			float errLen = len(sub(target, current));
			if (contact.minY >= FLOOR_Y - CONTACT_EPS && errLen < SOLVE_TOL) return;

			// CCD: iterate joints from foot parent -> root
			for (int iter = 0; iter < MAX_ITERS; iter++) {
				pose.rebuild();
				float[] footWorld = pose.worldByElem.get(foot);
				current = getAnchorWorld(foot, footWorld);
				float[] err = sub(target, current);
				if (len(err) < SOLVE_TOL) break;

				// Walk joints
				for (int i = 1; i < chainFootToRoot.size(); i++) {
					Element joint = chainFootToRoot.get(i);
					Element jointChild = chainFootToRoot.get(i - 1);

					// Joint pivot in world space
					float[] pivot = pose.getJointPivotWorld(joint);
					if (pivot == null) continue;

					pose.rebuild();
					footWorld = pose.worldByElem.get(foot);
					current = getAnchorWorld(foot, footWorld);

					float[] vEff = sub(current, pivot);
					float[] vTar = sub(target, pivot);
					if (len(vEff) < 1e-6f || len(vTar) < 1e-6f) continue;

					normalize(vEff);
					normalize(vTar);

					float dot = clamp(dot(vEff, vTar), -1f, 1f);
					float angle = (float)Math.acos(dot);
					if (angle < 1e-4f) continue;

					float[] axisW = cross(vEff, vTar);
					float axisLen = len(axisW);
					if (axisLen < 1e-6f) continue;
					normalize(axisW);

					// Convert world axis to joint-local axis
					float[] jointWorld = pose.worldByElem.get(joint);
					float[] axisL = worldAxisToLocal(axisW, jointWorld);
					if (len(axisL) < 1e-6f) continue;
					normalize(axisL);

					// Apply a capped rotation step
					float step = angle * 0.75f;
					float maxStep = 12f * GameMath.DEG2RAD;
					if (step > maxStep) step = maxStep;

					applyDeltaRotation(joint, anim, kfFrame, frame, axisL, step);
				}
			}

			// No translation clamp: this IK mode is rotation-only.
			// If the chain cannot fully prevent penetration using rotations alone,
			// we stop here and leave the remaining error (so we never modify position/scale).

		} finally {
			inSolve = false;
		}
	}

	private static List<Element> buildChain(Element foot)
	{
		List<Element> chain = new ArrayList<>();
		Element cur = foot;
		while (cur != null) {
			chain.add(cur);
			cur = cur.ParentElement;
		}
		return chain;
	}

	private static void applyDeltaRotation(Element joint, Animation anim, AnimationFrame kfFrame, int frame, float[] axisLocal, float angleRad)
	{
		AnimFrameElement kf = kfFrame.GetOrCreateKeyFrameElementFlat(frame, joint);
		kf.RotationSet = true;

		// Total current rotation (base + keyframe)
		double rx = (joint.getRotationX() + kf.getRotationX()) * GameMath.DEG2RAD;
		double ry = (joint.getRotationY() + kf.getRotationY()) * GameMath.DEG2RAD;
		double rz = (joint.getRotationZ() + kf.getRotationZ()) * GameMath.DEG2RAD;

		Quaternion qCur = QUtil.IntrinsicXYZToQuaternion(rx, ry, rz);
		Quaternion qDelta = QUtil.AxisAngleToQuat(axisLocal, angleRad);
		Quaternion qNew = new Quaternion();
		Quaternion.mul(qCur, qDelta, qNew); // local-space delta
		qNew.normalise();

		double[] euler = QUtil.ToIntrinsicXYZEuler(qNew); // radians, order X,Y,Z

		double newX = euler[0] * GameMath.RAD2DEG;
		double newY = euler[1] * GameMath.RAD2DEG;
		double newZ = euler[2] * GameMath.RAD2DEG;

		// Store only the delta part in the keyframe (base rotation stays on the Element)
		kf.setRotationX(wrapDeg(newX - joint.getRotationX()));
		kf.setRotationY(wrapDeg(newY - joint.getRotationY()));
		kf.setRotationZ(wrapDeg(newZ - joint.getRotationZ()));
	}

	private static float[] worldAxisToLocal(float[] axisWorld, float[] jointWorldMatrix)
	{
		// Extract basis vectors (columns 0,1,2) from the 3x3 rotation part
		float[] x = new float[] { jointWorldMatrix[0], jointWorldMatrix[1], jointWorldMatrix[2] };
		float[] y = new float[] { jointWorldMatrix[4], jointWorldMatrix[5], jointWorldMatrix[6] };
		float[] z = new float[] { jointWorldMatrix[8], jointWorldMatrix[9], jointWorldMatrix[10] };
		// Normalize basis (handles uniform scaling)
		normalizeSafe(x);
		normalizeSafe(y);
		normalizeSafe(z);

		// axisLocal = transpose(basis) * axisWorld
		return new float[] {
			dot(axisWorld, x),
			dot(axisWorld, y),
			dot(axisWorld, z)
		};
	}

	private static float wrapDeg(double deg)
	{
		double d = deg;
		while (d > 180) d -= 360;
		while (d < -180) d += 360;
		return (float)d;
	}

	private static float[] getAnchorWorld(Element foot, float[] footWorld)
	{
		float[] local = anchorLocal != null ? anchorLocal : new float[] { 0, 0, 0 };
		float[] out = Mat4f.MulWithVec4(footWorld, new float[] { local[0], local[1], local[2], 1f });
		return new float[] { out[0], out[1], out[2] };
	}

	private static ContactInfo computeFootContact(Element foot, float[] footWorld)
	{
		if (footWorld == null) return null;
		double w = foot.getWidth();
		double h = foot.getHeight();
		double d = foot.getDepth();

		float[][] corners = new float[][] {
			{ 0f, 0f, 0f },
			{ (float)w, 0f, 0f },
			{ 0f, (float)h, 0f },
			{ (float)w, (float)h, 0f },
			{ 0f, 0f, (float)d },
			{ (float)w, 0f, (float)d },
			{ 0f, (float)h, (float)d },
			{ (float)w, (float)h, (float)d }
		};

		float minY = Float.POSITIVE_INFINITY;
		float[][] worldPts = new float[corners.length][];
		for (int i = 0; i < corners.length; i++) {
			float[] v = corners[i];
			float[] out = Mat4f.MulWithVec4(footWorld, new float[] { v[0], v[1], v[2], 1f });
			worldPts[i] = new float[] { out[0], out[1], out[2] };
			if (worldPts[i][1] < minY) minY = worldPts[i][1];
		}

		// Determine anchor point by averaging all corners at the lowest y (within eps)
		float ax = 0, ay = 0, az = 0;
		int cnt = 0;
		for (int i = 0; i < worldPts.length; i++) {
			if (Math.abs(worldPts[i][1] - minY) <= 0.0005f) {
				ax += worldPts[i][0];
				ay += worldPts[i][1];
				az += worldPts[i][2];
				cnt++;
			}
		}
		if (cnt == 0) return null;
		ax /= cnt;
		ay /= cnt;
		az /= cnt;

		ContactInfo info = new ContactInfo();
		info.minY = minY;
		info.anchorX = ax;
		info.anchorY = ay;
		info.anchorZ = az;
		return info;
	}

	private static class ContactInfo
	{
		float minY;
		float anchorX;
		float anchorY;
		float anchorZ;
	}

	/**
	 * Computes world matrices for the chain elements based on the current keyframe data.
	 */
	private static class Pose
	{
		private final List<Element> chainFootToRoot;
		private final Animation anim;
		private final AnimationFrame kfFrame;
		private final int frame;

		HashMap<Element, float[]> worldByElem = new HashMap<>();
		HashMap<Element, float[]> pivotByElem = new HashMap<>();

		Pose(List<Element> chainFootToRoot, Animation anim, AnimationFrame kfFrame, int frame)
		{
			this.chainFootToRoot = chainFootToRoot;
			this.anim = anim;
			this.kfFrame = kfFrame;
			this.frame = frame;
		}

		void rebuild()
		{
			worldByElem.clear();
			pivotByElem.clear();

			// We need to compute from root -> foot
			float[] parentWorld = Mat4f.Create();
			for (int i = chainFootToRoot.size() - 1; i >= 0; i--) {
				Element elem = chainFootToRoot.get(i);
				AnimFrameElement kf = kfFrame.GetOrCreateKeyFrameElementFlat(frame, elem);

				float[] local = buildLocalMatrix(elem, kf);
				float[] world = Mat4f.Multiply(new float[16], parentWorld, local);
				worldByElem.put(elem, world);

				// Pivot (position of the joint origin at the moment of rotation)
				float[] pivotMat = Mat4f.CloneIt(parentWorld);
				float ox = (float)(elem.getOriginX() + kf.getOriginX());
				float oy = (float)(elem.getOriginY() + kf.getOriginY());
				float oz = (float)(elem.getOriginZ() + kf.getOriginZ());
				float sx = (float)(elem.getStartX() + kf.getOffsetX());
				float sy = (float)(elem.getStartY() + kf.getOffsetY());
				float sz = (float)(elem.getStartZ() + kf.getOffsetZ());
				Mat4f.Translate(pivotMat, pivotMat, new float[] { ox, oy, oz });
				Mat4f.Translate(pivotMat, pivotMat, new float[] { sx, sy, sz });
				float[] pivot4 = Mat4f.MulWithVec4(pivotMat, new float[] { 0, 0, 0, 1 });
				pivotByElem.put(elem, new float[] { pivot4[0], pivot4[1], pivot4[2] });

				parentWorld = world;
			}
		}

		float[] getJointPivotWorld(Element elem)
		{
			return pivotByElem.get(elem);
		}

		private float[] buildLocalMatrix(Element elem, AnimFrameElement kf)
		{
			float[] m = Mat4f.Create();

			float ox = (float)(elem.getOriginX() + kf.getOriginX());
			float oy = (float)(elem.getOriginY() + kf.getOriginY());
			float oz = (float)(elem.getOriginZ() + kf.getOriginZ());

			float sx = (float)(elem.getStartX() + kf.getOffsetX());
			float sy = (float)(elem.getStartY() + kf.getOffsetY());
			float sz = (float)(elem.getStartZ() + kf.getOffsetZ());

			float scx = (float)kf.getStretchX();
			float scy = (float)kf.getStretchY();
			float scz = (float)kf.getStretchZ();

			float rx = (float)((elem.getRotationX() + kf.getRotationX()) * GameMath.DEG2RAD);
			float ry = (float)((elem.getRotationY() + kf.getRotationY()) * GameMath.DEG2RAD);
			float rz = (float)((elem.getRotationZ() + kf.getRotationZ()) * GameMath.DEG2RAD);

			Mat4f.Translate(m, m, new float[] { ox, oy, oz });
			Mat4f.Translate(m, m, new float[] { sx, sy, sz });
			Mat4f.Scale(m, m, new float[] { scx, scy, scz });
			Mat4f.RotateX(m, m, rx);
			Mat4f.RotateY(m, m, ry);
			Mat4f.RotateZ(m, m, rz);
			Mat4f.Translate(m, m, new float[] { -ox, -oy, -oz });

			return m;
		}
	}

	// -------- minimal vector helpers --------

	private static float[] sub(float[] a, float[] b) { return new float[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] }; }
	private static float dot(float[] a, float[] b) { return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]; }
	private static float[] cross(float[] a, float[] b) {
		return new float[] {
			a[1]*b[2] - a[2]*b[1],
			a[2]*b[0] - a[0]*b[2],
			a[0]*b[1] - a[1]*b[0]
		};
	}
	private static float len(float[] v) { return (float)Math.sqrt(dot(v,v)); }
	private static void normalize(float[] v) {
		float l = len(v);
		if (l < 1e-8f) return;
		v[0] /= l; v[1] /= l; v[2] /= l;
	}
	private static void normalizeSafe(float[] v) {
		float l = len(v);
		if (l < 1e-8f) return;
		v[0] /= l; v[1] /= l; v[2] /= l;
	}
	private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
