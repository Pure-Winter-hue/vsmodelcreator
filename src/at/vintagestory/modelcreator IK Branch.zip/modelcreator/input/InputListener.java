package at.vintagestory.modelcreator.input;

import at.vintagestory.modelcreator.input.key.InputKeyEvent;

public interface InputListener
{
	public void update(InputKeyEvent event);
}
