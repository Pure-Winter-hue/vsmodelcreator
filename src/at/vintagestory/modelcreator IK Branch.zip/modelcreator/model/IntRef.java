package at.vintagestory.modelcreator.model;

public class IntRef
{
	public int value;
}
