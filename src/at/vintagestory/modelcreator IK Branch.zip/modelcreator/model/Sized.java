package at.vintagestory.modelcreator.model;

public class Sized
{
	public double W;
	public double H;
	
	public Sized() {}
	
	public Sized(double w, double h) {
		this.W = w;
		this.H = h;
	}
}
