package at.vintagestory.modelcreator.interfaces;

public interface ITextureCallback
{
	public void onTextureLoaded(boolean isNew, String errormessage, String texture);
}
