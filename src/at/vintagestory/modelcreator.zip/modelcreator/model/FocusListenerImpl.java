package at.vintagestory.modelcreator.model;

import java.awt.event.FocusEvent;

public class FocusListenerImpl implements java.awt.event.FocusListener
{
   public FocusListenerImpl()
   {
   }

	
	@Override
	public void focusGained(FocusEvent e)
	{
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void focusLost(FocusEvent e)
	{
		// TODO Auto-generated method stub
		
	}
}