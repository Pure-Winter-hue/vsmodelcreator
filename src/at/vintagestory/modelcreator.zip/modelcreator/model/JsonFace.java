package at.vintagestory.modelcreator.model;

public class JsonFace
{
	public String texture;
	public float[] uv = new float[4];
	public boolean enabled = true;
	
	
}
