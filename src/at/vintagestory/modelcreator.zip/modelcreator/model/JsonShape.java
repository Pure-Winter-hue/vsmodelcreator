package at.vintagestory.modelcreator.model;

import java.util.HashMap;
import java.util.Map;

public class JsonShape
{
	public Map<String, String> textures = new HashMap<String, String>();
	
	public JsonElement[] elements;
	
	
	
}
