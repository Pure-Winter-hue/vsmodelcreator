package at.vintagestory.modelcreator.model;

public class RenderFaceTask
{
	public Face face;
	public Element elem;
	
	public RenderFaceTask(Face face, Element elem) {
		this.face = face;
		this.elem = elem;
	}
}
