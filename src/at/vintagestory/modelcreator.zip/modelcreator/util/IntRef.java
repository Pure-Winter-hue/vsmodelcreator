package at.vintagestory.modelcreator.util;

public class IntRef
{
	public int value;
}
