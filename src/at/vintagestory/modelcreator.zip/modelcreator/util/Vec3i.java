package at.vintagestory.modelcreator.util;

public class Vec3i
{
	public int X;
	public int Y;
	public int Z;
}
