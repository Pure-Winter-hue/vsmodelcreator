package at.vintagestory.modelcreator.util.screenshot;

import java.io.File;

public interface ScreenshotCallback
{
	public void callback(File file);
}